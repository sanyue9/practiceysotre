let baseURL ='http://106.55.31.27:8080/api'


export default {
    login: baseURL + '/login',
    query: baseURL + '/query',
    reserve: baseURL + '/book'
}